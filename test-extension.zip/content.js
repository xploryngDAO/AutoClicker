// AutoApprove RPA — Content Script (Gravador da 1ª Rodada + Executor DOM em Segundo Plano)
(() => {
  let isRecording = false;
  let isRunning = false;
  let recordedSteps = [];
  let lastClickTs = performance.now();

  function computeResilientSelector(el) {
    if (!el || el.nodeType !== 1) return 'body';
    if (el.dataset?.action) return `${el.tagName.toLowerCase()}[data-action="${el.dataset.action}"]`;
    if (el.dataset?.testid) return `${el.tagName.toLowerCase()}[data-testid="${el.dataset.testid}"]`;
    if (el.id && !/\d{4,}/.test(el.id)) return `#${CSS.escape(el.id)}`;
    if (el.getAttribute('aria-label')) {
      return `${el.tagName.toLowerCase()}[aria-label="${el.getAttribute('aria-label')}"]`;
    }
    const parent = el.parentElement;
    if (!parent) return el.tagName.toLowerCase();
    const siblings = Array.from(parent.children).filter((c) => c.tagName === el.tagName);
    const idx = siblings.indexOf(el) + 1;
    return `${computeResilientSelector(parent)} > ${el.tagName.toLowerCase()}:nth-of-type(${idx})`;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function waitForSelector(selector, timeoutMs = 6000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const el = document.querySelector(selector);
      if (el && el.offsetParent !== null) return el;
      await sleep(150);
    }
    throw new Error(`Timeout aguardando seletor: ${selector}`);
  }

  function logToExtension(level, message, outcome) {
    chrome.runtime.sendMessage({
      type: 'APPEND_LOG',
      entry: {
        timestamp: new Date().toISOString(),
        level,
        message,
        outcome
      }
    });
  }

  document.addEventListener(
    'click',
    (ev) => {
      if (!isRecording) return;
      const target = ev.target.closest('button, a, input, select, tr, [role="button"]') || ev.target;
      const selector = computeResilientSelector(target);
      const now = performance.now();
      const waitBeforeMs = Math.min(2500, Math.max(200, Math.round(now - lastClickTs)));
      lastClickTs = now;

      const step = {
        id: 'ext-step-' + (recordedSteps.length + 1),
        order: recordedSteps.length + 1,
        label: (target.innerText || target.getAttribute('aria-label') || target.tagName).trim().slice(0, 60),
        action: target.type === 'checkbox' ? 'check' : target.tagName === 'SELECT' ? 'select' : 'click',
        cssSelector: selector,
        waitBeforeMs,
        timeoutMs: 6000
      };
      recordedSteps.push(step);
      chrome.storage.local.set({ rpaSteps: recordedSteps });
      logToExtension('info', `Passo #${step.order} gravado: ${step.cssSelector}`);
    },
    true
  );

  async function executeBatchLoop(config, steps) {
    if (isRunning) return;
    isRunning = true;
    logToExtension('info', `Iniciando lote em segundo plano com ${steps.length} passos por acesso.`);

    while (isRunning) {
      const challengeFrame = document.querySelector('iframe[src*="challenges"], iframe[src*="recaptcha"]');
      if (challengeFrame) {
        isRunning = false;
        logToExtension('warn', 'Verificação/CAPTCHA detectado — aguardando operador na aba.', 'challenge');
        break;
      }

      const pendingRow = document.querySelector(config.rowSelector);
      if (!pendingRow) {
        isRunning = false;
        logToExtension('success', 'Nenhuma solicitação pendente restante na página.', 'completed');
        break;
      }

      let ok = false;
      for (let attempt = 1; attempt <= (config.maxRetries || 3); attempt++) {
        try {
          for (const step of steps) {
            if (!isRunning) return;
            const jitter = Math.floor(Math.random() * (config.randomJitterMs || 300));
            await sleep((step.waitBeforeMs || 250) + jitter);
            const el = await waitForSelector(step.cssSelector, step.timeoutMs || 6000);
            el.scrollIntoView({ block: 'center', behavior: 'instant' });
            if (step.action === 'check') {
              if (!el.checked) el.click();
            } else if (step.action === 'select' && step.value) {
              el.value = step.value;
              el.dispatchEvent(new Event('change', { bubbles: true }));
            } else {
              el.click();
            }
          }
          ok = true;
          logToExtension('success', 'Solicitação aprovada com sucesso.', 'approved');
          break;
        } catch (err) {
          logToExtension('warn', `Tentativa ${attempt} falhou: ${err.message}`);
          await sleep(800 * attempt);
        }
      }

      if (!ok) {
        logToExtension('error', 'Item marcado como falha após máximo de tentativas.', 'failed');
      }

      await sleep((config.baseDelayMs || 400) + Math.floor(Math.random() * 250));
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'START_RECORDING') {
      isRecording = true;
      recordedSteps = [];
      lastClickTs = performance.now();
      logToExtension('info', 'Modo Aprendizado (1ª Rodada) ativado na aba atual.');
      sendResponse({ ok: true });
    } else if (msg.type === 'STOP_RECORDING') {
      isRecording = false;
      logToExtension('success', `Gravação concluída com ${recordedSteps.length} passos salvos.`);
      sendResponse({ ok: true, count: recordedSteps.length });
    } else if (msg.type === 'RPA_EXECUTE_LOOP') {
      executeBatchLoop(msg.config, msg.steps);
      sendResponse({ ok: true });
    } else if (msg.type === 'RPA_ABORT') {
      isRunning = false;
      logToExtension('warn', 'Execução interrompida pelo operador.');
      sendResponse({ ok: true });
    }
    return true;
  });
})();
