let recording = false;

async function refreshUI() {
  const { rpaSteps = [], rpaLogs = [], rpaStats = {} } = await chrome.storage.local.get([
    'rpaSteps',
    'rpaLogs',
    'rpaStats'
  ]);
  document.getElementById('st-status').textContent = rpaStats.status || 'idle';
  document.getElementById('st-approved').textContent = String(rpaStats.approved || 0);
  document.getElementById('st-failed').textContent = String(rpaStats.failed || 0);
  document.getElementById('step-count').textContent = String(rpaSteps.length);

  const stepList = document.getElementById('step-list');
  stepList.innerHTML = rpaSteps
    .map((s) => `<li><strong>${s.action}</strong> · <code>${s.cssSelector}</code></li>`)
    .join('');

  const logList = document.getElementById('log-list');
  logList.innerHTML = rpaLogs
    .slice(0, 80)
    .map((l) => `<div class="log-row">[${l.timestamp.slice(11, 19)}] ${l.message}</div>`)
    .join('');
}

document.getElementById('btn-record').addEventListener('click', async (ev) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  recording = !recording;
  ev.target.textContent = recording ? 'Finalizar Gravação da 1ª Rodada' : 'Gravar 1ª Rodada na Aba';
  await chrome.tabs.sendMessage(tab.id, { type: recording ? 'START_RECORDING' : 'STOP_RECORDING' });
  refreshUI();
});

document.getElementById('btn-start').addEventListener('click', async () => {
  const openDedicatedBackgroundTab = document.getElementById('chk-bg-tab').checked;
  await chrome.runtime.sendMessage({ type: 'START_BACKGROUND_BATCH', openDedicatedBackgroundTab });
  refreshUI();
});

document.getElementById('btn-stop').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'STOP_BACKGROUND_BATCH' });
  refreshUI();
});

document.getElementById('btn-export').addEventListener('click', async () => {
  const { rpaLogs = [] } = await chrome.storage.local.get('rpaLogs');
  const csv = ['timestamp,level,outcome,message']
    .concat(rpaLogs.map((l) => `"${l.timestamp}","${l.level}","${l.outcome || ''}","${(l.message || '').replace(/"/g, '""')}"`))
    .join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'auditoria_extensao_rpa.csv';
  a.click();
});

chrome.storage.onChanged.addListener(refreshUI);
refreshUI();
