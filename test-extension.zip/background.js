// AutoApprove RPA — Service Worker MV3 (Execução em Segundo Plano)
const DEFAULT_CONFIG = {
  targetUrl: "https://governanca.empresa.com.br/iam/aprovacoes-pendentes",
  rowSelector: "tr[data-request-status=\"pending\"]",
  baseDelayMs: 420,
  randomJitterMs: 380,
  maxRetries: 3
};

const DEFAULT_STEPS = [
  {
    "id": "step-1",
    "order": 1,
    "label": "Selecionar linha da solicitação pendente na grade",
    "action": "click",
    "cssSelector": "tr[data-request-status=\"pending\"]:first-of-type",
    "ariaSelector": "role=row[name=/IAM-2026/i]",
    "waitBeforeMs": 280,
    "timeoutMs": 8000,
    "isLoopTarget": true
  },
  {
    "id": "step-2",
    "order": 2,
    "label": "Marcar aceite de conformidade LGPD / Governança",
    "action": "check",
    "cssSelector": "input[data-testid=\"policy-compliance-checkbox\"]",
    "ariaSelector": "role=checkbox[name=\"Confirmo revisão de alçada e conformidade\"]",
    "waitBeforeMs": 240,
    "timeoutMs": 5000,
    "isLoopTarget": true
  },
  {
    "id": "step-3",
    "order": 3,
    "label": "Selecionar vigência padrão de concessão (90 dias)",
    "action": "select",
    "cssSelector": "select[data-testid=\"grant-duration-select\"]",
    "ariaSelector": "role=combobox[name=\"Vigência da concessão\"]",
    "value": "90d",
    "waitBeforeMs": 220,
    "timeoutMs": 5000,
    "isLoopTarget": true
  },
  {
    "id": "step-4",
    "order": 4,
    "label": "Acionar botão primário Aprovar Concessão",
    "action": "click",
    "cssSelector": "button[data-action=\"approve-access\"]",
    "ariaSelector": "role=button[name=\"Aprovar Concessão\"]",
    "waitBeforeMs": 320,
    "timeoutMs": 6000,
    "isLoopTarget": true
  },
  {
    "id": "step-5",
    "order": 5,
    "label": "Confirmar efetivação no diálogo de auditoria",
    "action": "click",
    "cssSelector": "button[data-action=\"confirm-modal-submit\"]",
    "ariaSelector": "role=button[name=\"Confirmar e Assinar\"]",
    "waitBeforeMs": 300,
    "timeoutMs": 8000,
    "isLoopTarget": true
  }
];

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(['rpaSteps', 'rpaConfig', 'rpaLogs', 'rpaStats']);
  if (!stored.rpaSteps) await chrome.storage.local.set({ rpaSteps: DEFAULT_STEPS });
  if (!stored.rpaConfig) await chrome.storage.local.set({ rpaConfig: DEFAULT_CONFIG });
  if (!stored.rpaLogs) await chrome.storage.local.set({ rpaLogs: [] });
  if (!stored.rpaStats) {
    await chrome.storage.local.set({
      rpaStats: { status: 'idle', approved: 0, failed: 0, targetTabId: null }
    });
  }
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
});

// Mantém o ciclo vivo enquanto houver um lote em segundo plano ativo
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== 'rpa-heartbeat') return;
  const { rpaStats } = await chrome.storage.local.get('rpaStats');
  if (rpaStats?.status === 'running' && rpaStats.targetTabId) {
    try {
      await chrome.tabs.sendMessage(rpaStats.targetTabId, { type: 'RPA_HEARTBEAT_NEXT' });
    } catch {
      // Aba fechada ou recarregando
    }
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg.type === 'START_BACKGROUND_BATCH') {
      const { rpaConfig, rpaSteps } = await chrome.storage.local.get(['rpaConfig', 'rpaSteps']);
      let targetTab = null;
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });

      if (msg.openDedicatedBackgroundTab) {
        targetTab = await chrome.tabs.create({ url: rpaConfig.targetUrl, active: false, pinned: true });
      } else {
        targetTab = activeTab;
      }

      if (!targetTab?.id) {
        sendResponse({ ok: false, error: 'Nenhuma aba alvo localizada.' });
        return;
      }

      await chrome.storage.local.set({
        rpaStats: { status: 'running', approved: 0, failed: 0, targetTabId: targetTab.id }
      });
      await chrome.alarms.create('rpa-heartbeat', { periodInMinutes: 0.4 });
      await chrome.tabs.sendMessage(targetTab.id, {
        type: 'RPA_EXECUTE_LOOP',
        config: rpaConfig,
        steps: rpaSteps
      });
      sendResponse({ ok: true, tabId: targetTab.id });
    } else if (msg.type === 'STOP_BACKGROUND_BATCH') {
      const { rpaStats } = await chrome.storage.local.get('rpaStats');
      if (rpaStats?.targetTabId) {
        chrome.tabs.sendMessage(rpaStats.targetTabId, { type: 'RPA_ABORT' }).catch(() => {});
      }
      await chrome.alarms.clear('rpa-heartbeat');
      await chrome.storage.local.set({
        rpaStats: { ...(rpaStats || {}), status: 'idle' }
      });
      sendResponse({ ok: true });
    } else if (msg.type === 'APPEND_LOG') {
      const { rpaLogs = [], rpaStats = {} } = await chrome.storage.local.get(['rpaLogs', 'rpaStats']);
      const nextLogs = [msg.entry, ...rpaLogs].slice(0, 500);
      const nextStats = { ...rpaStats };
      if (msg.entry.outcome === 'approved') nextStats.approved = (nextStats.approved || 0) + 1;
      if (msg.entry.outcome === 'failed') nextStats.failed = (nextStats.failed || 0) + 1;
      if (msg.entry.outcome === 'completed' || msg.entry.outcome === 'challenge') {
        nextStats.status = msg.entry.outcome === 'challenge' ? 'paused_challenge' : 'completed';
      }
      await chrome.storage.local.set({ rpaLogs: nextLogs, rpaStats: nextStats });
      sendResponse({ ok: true });
    }
  })();
  return true;
});
